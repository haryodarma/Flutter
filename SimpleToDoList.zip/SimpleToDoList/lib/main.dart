// Packages
import 'package:flutter/material.dart';
import 'package:lsitview/Pages/addpesilat.dart';
import 'package:lsitview/Pages/detailpesilat.dart';

// Page
import 'package:lsitview/Pages/home_page.dart';
import 'package:lsitview/Providers/datapesilat.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(
      create: (context) => DataPesilat(),
    )
  ], child: MyApp()));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          appBarTheme: AppBarTheme(
              color: Colors.orangeAccent,
              elevation: 10,
              shadowColor: Colors.black,
              titleTextStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                  fontWeight: FontWeight.bold))),
      home: HomePage(),
      routes: {
        AddPesilat.routeName: (context) => AddPesilat(),
        DetailPesilat.routeName: (context) => DetailPesilat(),
      },
    );
  }
}
