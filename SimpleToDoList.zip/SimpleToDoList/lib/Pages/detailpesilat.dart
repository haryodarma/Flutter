import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:lsitview/Providers/datapesilat.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class DetailPesilat extends StatelessWidget {
  static const routeName = '/detailPesilat';
  TextEditingController nameController = TextEditingController();
  TextEditingController roleController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final theID = ModalRoute.of(context)!.settings.arguments.toString();
    final providers = Provider.of<DataPesilat>(context);
    final dataSilat = providers.allData.firstWhere((e) => e.id == theID);
    nameController.text = dataSilat.name;
    roleController.text = dataSilat.role;
    return Scaffold(
      appBar: AppBar(
        title: Text(dataSilat.name),
      ),
      body: Container(
        padding: EdgeInsets.all(30),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(100)),
              child: Container(
                width: 150,
                height: 150,
                child: Image(
                  fit: BoxFit.fill,
                  image: NetworkImage(
                    dataSilat.imageURL,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            TextField(
              controller: nameController,
            ),
            SizedBox(
              height: 10,
            ),
            TextField(
              controller: roleController,
            ),
            SizedBox(
              height: 30,
            ),
            TextButton(
                onPressed: () {
                  providers.edit(
                      dataSilat.id, nameController.text, roleController.text);
                  Navigator.of(context).pop();
                },
                child: Text("Ubah"))
          ],
        ),
      ),
    );
  }
}
