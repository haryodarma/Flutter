import 'package:flutter/material.dart';
import 'package:lsitview/Pages/addpesilat.dart';

import 'package:lsitview/Providers/datapesilat.dart';
import 'package:provider/provider.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final silat = Provider.of<DataPesilat>(context);
    final dataPesilat = silat.allData;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Simple To Do List',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddPesilat.routeName);
              },
              icon: Icon(
                Icons.add,
                color: Colors.red,
              )),
        ],
      ),
      body:
       
          Container(
        child: (dataPesilat.isEmpty)
            ? Center(
                child: TextButton(
                onPressed: () {
                  Navigator.of(context).pushNamed(AddPesilat.routeName);
                },
                child: Text(
                  'No Data',
                  style: TextStyle(
                      fontSize: 30,
                      color: const Color.fromARGB(255, 61, 61, 61),
                      fontWeight: FontWeight.bold),
                ),
              ))
            :
            // Column(children: [
            //
            ListView.builder(
                // scrollDirection: Axis.vertical,
                itemCount: dataPesilat.length,
                itemBuilder: (context, i) => CheckboxListTile(
                      checkColor: Colors.amber,
                      side: BorderSide(color: Colors.white, width: 1),
                      tileColor: (dataPesilat[i].role == 'Penting')
                          ? (dataPesilat[i].check)
                              ? Colors.grey
                              : Colors.red
                          : (dataPesilat[i].check)
                              ? Colors.grey
                              : Colors.amber,
                      activeColor: Colors.green,

                      selectedTileColor: Colors.yellow,
                      onChanged: (value) {
                        silat.checked(dataPesilat[i].id);
                      },
                      value: dataPesilat[i].check,
                      // onTap: () {
                      //   Navigator.of(context).pushNamed(DetailPesilat.routeName,
                      //       arguments: dataPesilat[i].id);
                      // },
                      title: (dataPesilat[i].check)
                          ? Text(
                              dataPesilat[i].name,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  decoration: TextDecoration.lineThrough),
                            )
                          : Text(
                              dataPesilat[i].name,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 20),
                            ),
                      subtitle: Text(
                        dataPesilat[i].role,
                        style: TextStyle(color: Colors.white),
                      ),
                      // leading: CircleAvatar(
                      //   backgroundImage: NetworkImage(dataPesilat[i].imageURL),
                      // ),
                      // trailing: IconButton(
                      //   icon: Icon(Icons.delete),
                      //   onPressed: () => silat.delete(dataPesilat[i].id),
                      // ),
                    )),
        // ]),
      ),
      //   ],
      // ),
    );
  }
}
