import 'package:flutter/material.dart';
import 'package:lsitview/Providers/datapesilat.dart';
import 'package:provider/provider.dart';

class AddPesilat extends StatelessWidget {
  static const routeName = '/addPesilat';
  final TextEditingController nameController = TextEditingController();

  List role = ['Penting', 'Tidak Terlalu'];
  String? initValue = 'baru';
  void onChanged(String value) {
    initValue = value;
  }

  String roleValue = 'Penting';
  @override
  Widget build(BuildContext context) {
    final providers = Provider.of<DataPesilat>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Add Task'),
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  icon: Icon(Icons.person),
                )),
            SizedBox(
              height: 20,
            ),
            DropdownMenu(
              initialSelection: role.first,
              onSelected: (value) {
                roleValue = value;
              },
              dropdownMenuEntries: role.map((e) {
                return DropdownMenuEntry(value: e, label: e);
              }).toList(),
            ),
            SizedBox(
              height: 20,
            ),
            TextButton(
                onPressed: () {
                  if (nameController.text.isNotEmpty) {
                    providers.add(nameController.text, roleValue);
                    Navigator.of(context).pop();
                  }
                },
                child: Text('Add'))
          ],
        ),
      ),
    );
  }
}
