import 'package:flutter/material.dart';
import 'package:lsitview/Model/pesilat.dart';

class DataPesilat with ChangeNotifier {
  List<Pesilat> _allData = [];
  List<Pesilat> get allData => _allData;
  bool allSelected = false;
  void add(String name, String role) {
    allData.add(Pesilat(DateTime.now().toString(),
        'https://picsum.photos/200/300', name, role));
    notifyListeners();
  }

  void delete(tanda) {
    allData.removeWhere((id) => id.id == tanda);
    notifyListeners();
  }

  void edit(id, name, role) {
    var edit = allData.firstWhere((e) => e.id == id);
    edit.name = name;
    edit.role = role;
    notifyListeners();
  }

  void checked(tanda) {
    var data = allData.firstWhere((id) => id.id == tanda);
    data.check = !data.check;
    if (data.check == true) {
      allData.removeWhere((id) => id.id == tanda);
      _allData.add(data);
    } else {
      allData.removeWhere((id) => id.id == tanda);
      _allData.insert(0, data);
    }

    notifyListeners();
  }

  void selectAll() {
    allData.forEach((e) => e.check = !e.check);
    notifyListeners();
  }
}
