class Pesilat {
  String id;
  bool check = false;
  String imageURL = '';
  String name = '';
  String role = '';

  Pesilat(this.id, this.imageURL, this.name, this.role);
}
