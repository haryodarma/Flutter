import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class funcs {
  int number = 0;
  bool isDark = false;
  ThemeData dark = ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.deepPurple,
    primarySwatch: Colors.deepPurple,
    appBarTheme: AppBarTheme(backgroundColor: Colors.deepPurple),
  );
  ThemeData light = ThemeData(
    brightness: Brightness.light,
    primaryColor: Colors.blue,
    primarySwatch: Colors.blue,
    appBarTheme: AppBarTheme(backgroundColor: Colors.blue),
  );

  Future<void> saveData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey('myData')) {
      prefs.clear();
    }
    ;

    final myData =
        jsonEncode({'number': number.toString(), 'isDark': isDark.toString()});
    prefs.setString('myData', myData);
  }

  Future<void> getData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey('myData')) {
      final data =
          jsonDecode(prefs.getString('myData')!) as Map<String, dynamic>;
      number = int.parse(data['number']);
      isDark = data['isDark'] == 'true' ? true : false;
    }
  }

  void refresh() {
    number = 0;
    isDark = false;
  }

  void add() {
    number++;
  }

  void min() {
    number--;
  }

  void changeTheme() {
    isDark = !isDark;
  }
}
