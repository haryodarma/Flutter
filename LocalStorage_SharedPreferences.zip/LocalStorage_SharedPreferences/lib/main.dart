import 'package:flutter/material.dart';
import 'package:shared_preferences_test/functions.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var func = funcs();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    func.getData();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: func.isDark ? func.dark : func.light,
      home: Scaffold(
        floatingActionButton: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
                onPressed: () {
                  func.refresh();
                  func.saveData();
                  setState(() {});
                },
                icon: Icon(size: 35, Icons.refresh)),
            IconButton(
                onPressed: () {
                  func.changeTheme();
                  func.saveData();
                  setState(() {});
                },
                icon: Icon(size: 35, Icons.color_lens)),
          ],
        ),
        appBar: AppBar(
          title: Text('Shared Preferences'),
          actions: [
            IconButton(
                onPressed: () {
                  func.getData();
                },
                icon: Icon(Icons.get_app))
          ],
        ),
        body: FutureBuilder(
          future: func.getData(),
          builder: (ctx, ss) => ConnectionState == ConnectionState.waiting
              ? Center(child: CircularProgressIndicator())
              : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${func.number}',
                        style: TextStyle(fontSize: 40),
                      ),
                      SizedBox(
                        height: 50,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              func.min();
                              func.saveData();
                              setState(() {});
                            },
                            child: Icon(Icons.remove),
                          ),
                          ElevatedButton(
                              onPressed: () {
                                func.add();
                                func.saveData();
                                setState(() {});
                              },
                              child: Icon(Icons.add)),
                        ],
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}
